package hus.oop.lab6;

public class TestShapes {
    public static void main(String[] args) {

        Square square1 = new Square(5);
        System.out.println(square1);
        System.out.println(square1.getArea());
        System.out.println(square1.getPerimeter());
    }
}
