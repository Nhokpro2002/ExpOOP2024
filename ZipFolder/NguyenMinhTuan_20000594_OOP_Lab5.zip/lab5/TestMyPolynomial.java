package hus.oop.lab5;

public class TestMyPolynomial {
}
