package hus.oop.lab5;

public class Container {

    private int x1;
    private int y1;
    private int x2;
    private int y2;
}
