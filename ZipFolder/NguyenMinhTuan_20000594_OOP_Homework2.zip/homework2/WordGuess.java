package hus.oop.homework2;

import java.util.Scanner;

public class WordGuess {

    public static void main(String[] args) {

    }

    public static void guessWord () {
        String Str = "homework";
        Boolean[] array = new Boolean[Str.length()];

    }

    public static void guessWord (String guessedString, Scanner in) {
        while (true) {
            System.out.print("Key in one character or your guess word: ");
            guessedString = in.next();
        }
    }
}
