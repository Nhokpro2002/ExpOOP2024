package hus.oop.homework2;

public class TimeTable {

    public static void main(String[] args) {

    }

    public static void timeTable(int n) {

    }
}
