package hus.oop.lap1;

public class SumAverageRunningInt2 {
    public static void main(String[] args) {

    }
}
