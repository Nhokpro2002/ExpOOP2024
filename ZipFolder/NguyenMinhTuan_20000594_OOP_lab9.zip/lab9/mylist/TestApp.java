package hus.oop.lab9.mylist;

public class TestApp {
    public static void main(String[] args) {
        MyList list = new MyArrayList();
        list.add("a", 0);
        list.add("b");
        list.add("b");
        list.add("c", 0);
        list.add("c", 3);
        //list.remove(3);
       // list.remove(1);
        //list.remove(2);
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
        System.out.println(list.size());
        System.out.println();
    }
}
