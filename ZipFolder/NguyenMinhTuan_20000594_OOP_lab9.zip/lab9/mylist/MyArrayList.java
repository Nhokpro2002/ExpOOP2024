package hus.oop.lab9.mylist;

public class MyArrayList extends MyAbstractList {
    int size;
    Object[] elements;
    static final int INITIAL_SIZE = 16;

    public MyArrayList() {
        elements = new Object[INITIAL_SIZE];
        size = 0;
    }

    @Override
    public void add(Object o) {
        if (size >= elements.length - 1) {
            enlarge();
        }
        elements[size++] = o;
    }

    @Override
    public void add(Object o, int index) {
        checkBoundaries(index, size);
        Object[] temp = new Object[size + 1];
        for (int i = 0; i <= index; i++) {
            temp[i] = elements[i];
            if (i == index) {
                temp[index] = o;
            }
        }

        for (int j = index + 1; j < temp.length; j++) {
            temp[j] = elements[j - 1];
        }
        elements = temp;
        size++;
    }

    @Override
    public Object get(int index) {
        for (int i = 0; i < size; i++) {
            if (i == index) {
                return elements[i];
            }
        }
        return null;
    }

    @Override
    public void remove(int index) {
        checkBoundaries(index, size);
        //int i = 0;
       for (int i = 0; i < elements.length; i++) {
           if (i == index) {
               for (int j = i; j < elements.length - 1; j++) {
                   elements[j] = elements[j + 1];
               }
           }
       }
       size--;
    }

    @Override
    public int size() {
        return size--;
    }

    void enlarge() {
        Object[] tmp = new Object[elements.length * 2];
        System.arraycopy(elements, 0, tmp, 0, elements.length);
        elements = tmp;
    }
}
