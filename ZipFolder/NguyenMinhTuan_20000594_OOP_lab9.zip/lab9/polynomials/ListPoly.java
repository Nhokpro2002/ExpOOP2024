package hus.oop.lab9.polynomials;

import java.util.List;
import java.util.ArrayList;
public class ListPoly extends AbstractPoly {
    List<Double> coefficients = new ArrayList<>();

    public ListPoly(double[] coeffs) {
        for (double i: coeffs) {
            coefficients.add(i);
        }
    }

    @Override
    public int degree() {
        return coefficients.size() - 1;
    }

    @Override
    public Poly derivative() {
       // double[] doubleCoefficientsArray = coefficients.toArray();
        double[] derCoeffs = this.derive();
        return new ListPoly(derCoeffs);
    }

    @Override
    public double coefficient(int degree) {
        return coefficients.size() - 1;
    }

    @Override
    public double[] coefficients() {
        double[] newCoefficientsArray = new double[coefficients.size()];
        for (int i = 0; i < newCoefficientsArray.length; i++) {
            newCoefficientsArray[i] = coefficients.get(i);
        }
        return newCoefficientsArray;
    }
}
