package hus.oop.lab9.polynomials;

import java.util.Objects;

/**
 * An abstract class providing an implementation for shared parts of
 * ArrayPoly and ListPoly
 */
public abstract class AbstractPoly implements Poly {

    int degree;

    public AbstractPoly() {

    }

    @Override
    public int degree() {
        degree = coefficients().length - 1;
        return degree;
    }
    double[] derive() {
        // TODO
        double[] doubleArray = new double[degree() - 1];
        for (int i = 0; i < doubleArray.length; i++) {
            doubleArray[i] = (i + 1) * coefficients()[i + 1];
        }
        return doubleArray;
    }

    @Override
    public boolean equals(Object o) {
        // TODO
        AbstractPoly poly = (AbstractPoly) o;
        if (o == null) {
            return false;
        }

        if (this.degree() != poly.degree()) {
            return false;
        }

        for (int i = 0; i <= degree; i++) {
            if (this.coefficients()[i] != poly.coefficients()[i]) {
                return false;
            }
        }
        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(coefficients());
    }

    @Override
    public String toString() {
        // TODO
        String stringPoly = coefficients()[0] + " + ";
        stringPoly += coefficients()[1] + "x " + " ";
        for (int i = 2; i <= degree(); i++) {
            if (i == degree()) {
                stringPoly += "+ " + coefficients()[i] + "x^" + degree();
            } else {
                stringPoly += "+ " + coefficients()[i] + "x^" + i + " ";
            }
        }
        return stringPoly;
    }
}
