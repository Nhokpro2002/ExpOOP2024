package hus.oop.lab9.polynomials;

public class ArrayPoly extends AbstractPoly {
    private double[] coefficients;

    public ArrayPoly(double[] coefficients) {
        this.coefficients = coefficients;
    }

    @Override
    public int degree() {
        return coefficients.length - 1;
    }

    @Override
    public Poly derivative() {
        double[] derivativeCoefficients = this.derive();
       // this.coefficients = derivativeCoefficients;

        return new ArrayPoly(derivativeCoefficients);
    }

    @Override
    public double coefficient(int degree) {
        return coefficients.length - 1;
    }

    @Override
    public double[] coefficients() {
        return this.coefficients;
    }

    public String type() {
        return "Array poly";
    }

}
