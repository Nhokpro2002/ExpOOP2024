package hus.oop.lab8.countryarraymanager;

public class CountryArrayManager {
    private Country[] countries;
    private int length;

    public CountryArrayManager() {
        countries = new Country[1];
        this.length = 0;
    }

    public CountryArrayManager(int maxLength) {
        countries = new Country[maxLength];
        this.length = 0;
    }

    public int getLength() {
        return this.length;
    }

    public Country[] getCountries() {
        return this.countries;
    }

    private void correct() {
        int nullFirstIndex = 0;
        for (int i = 0; i < this.countries.length; i++) {
            if (this.countries[i] == null) {
                nullFirstIndex = i;
                break;
            }
        }

        if (nullFirstIndex > 0) {
            this.length = nullFirstIndex;
            for (int i = nullFirstIndex; i < this.countries.length; i++) {
                this.countries[i] = null;
            }
        }
    }

    private void allocateMore() {
        Country[] newArray = new Country[2 * this.countries.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.countries.length);
        this.countries = newArray;
    }

    public void append(Country country) {
        if (this.length >= this.countries.length) {
            allocateMore();
        }

        this.countries[this.length] = country;
        this.length++;
    }

    public boolean add(Country country, int index) {
        if ((index < 0) || (index > this.countries.length)) {
            return false;
        }

        if (this.length >= this.countries.length) {
            allocateMore();
        }

        for (int i = this.length; i > index; i--) {
            this.countries[i] = this.countries[i - 1];
        }

        this.countries[index] = country;
        this.length++;
        return true;
    }

    public boolean remove(int index) {
        if ((index < 0) || (index >= countries.length)) {
            return false;
        }

        for (int i = index; i < length - 1; i++) {
            this.countries[i] = this.countries[i + 1];
        }

        this.countries[this.length - 1] = null;
        this.length--;
        return true;
    }

    public Country countryAt(int index) {
        if ((index < 0) || (index >= this.length)) {
            return null;
        }

        return this.countries[index];
    }

    /**
     * Sort the countries in order of increasing population
     * using selection sort algorithm
     * @return array of increasing population countries
     */
    public Country[] sortByIncreasingPopulation() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.length);

        for (int i = 0; i < newArray.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < newArray.length; j++) {
                if (newArray[j].getPopulation() < newArray[i].getPopulation()) {
                    minIndex = j;
                }
            }

            Country temp = newArray[i];
            newArray[i] = newArray[minIndex];
            newArray[minIndex] = temp;
        }

        return newArray;
    }

    /**
     * Sort the countries in order of decreasing population
     * using selection sort algorithm
     * @return array of increasing population countries
     */

    public Country[] sortByDecreasingPopulation() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.length);

        for (int i = 0; i < newArray.length - 1; i++) {
            int maxIndex = i;
            for (int j = i + 1; j < newArray.length; j++) {
                if (newArray[j].getPopulation() > newArray[i].getPopulation()) {
                    maxIndex = j;
                }
            }

            Country temp = newArray[i];
            newArray[i] = newArray[maxIndex];
            newArray[maxIndex] = temp;
        }
        return newArray;
    }

    /**
     * Sort the countries in order of increasing area
     * using bubble sort algorithm
     * @return array of increasing area countries
     */

    public Country[] sortByIncreasingArea() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.length);

        boolean swapped;
        for (int i = 0; i < newArray.length - 1; i++) {
            swapped = false;
            for (int j = 0; j < newArray.length; j++) {
                if (newArray[j].getArea() > newArray[j + 1].getArea()) {
                    Country temp = newArray[j];
                    newArray[j] = newArray[j = 1];
                    newArray[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break;
            }
        }

        return newArray;
    }

    /**
     * Sort the countries in order of decreasing area
     * using bubble sort algorithm
     * @return array of increasing area countries
     */

    public Country[] sortByDecreasingArea() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(countries, 0, newArray, 0, this.length);

        boolean swapped;
        for (int i = 0; i < newArray.length - 1; i++) {
            swapped = false;
            for (int j = 0; j < newArray.length; j++) {
                if (newArray[j].getArea() < newArray[j + 1].getArea()) {
                    Country temp = newArray[j];
                    newArray[j] = newArray[j = 1];
                    newArray[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break;
            }
        }

        return newArray;
    }

    /**
     * Sort the countries in order of increasing GDP
     * using insertion sort algorithm
     * @return array of increasing GDP countries
     */

    public Country[] sortByIncreasingGDP() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(countries, 0, newArray, 0, this.length);

       for (int i = 1; i < newArray.length; i++) {
           Country temp = newArray[i];
           double key = temp.getGdp();
           int j = i;

           while (j > 0 && key < newArray[j - 1].getGdp()) {
               temp = newArray[j - 1];
               j--;
           }
       }
       return newArray;
    }

    public Country[] sortByDecreasingGDP() {
        Country[] newArray = new Country[this.length];
        System.arraycopy(this.countries, 0, newArray, 0, this.length);

        return newArray;
    }

    public AfricaCountry[] filterAfricaCountry() {
        /* TODO */
        int count = 0;
        for (Country country: countries) {
            if (country instanceof AfricaCountry) {
                count++;
            }
        }

        AfricaCountry[] africaCountries = new AfricaCountry[count];

        for (int i = 0; i < this.length; i++) {
            if (countries[i] instanceof AfricaCountry) {
                africaCountries[i] = (AfricaCountry) countries[i];
            }
        }

        return africaCountries;
    }

    public AsiaCountry[] filterAsiaCountry() {
        /* TODO */
        int count = 0;
        for (Country country: countries) {
            if (country instanceof AsiaCountry) {
                count++;
            }
        }

        AsiaCountry[] asiaCountries = new AsiaCountry[count];

        for (int i = 0; i < this.length; i++) {
            if (countries[i] instanceof AsiaCountry) {
                asiaCountries[i] = (AsiaCountry) countries[i];
            }
        }

        return asiaCountries;
    }

    public EuropeCountry[] filterEuropeCountry() {
        /* TODO */
        int count = 0;
        for (Country country: countries) {
            if (country instanceof EuropeCountry) {
                count++;
            }
        }

        EuropeCountry[] europeCountries = new EuropeCountry[count];

        for (int i = 0; i < this.length; i++) {
            if (countries[i] instanceof EuropeCountry) {
                europeCountries[i] = (EuropeCountry) countries[i];
            }
        }

        return europeCountries;
    }

    public NorthAmericaCountry[] filterNorthAmericaCountry() {
        /* TODO */
        int count = 0;
        for (Country country: countries) {
            if (country instanceof NorthAmericaCountry) {
                count++;
            }
        }

        NorthAmericaCountry[] northAmericaCountries = new NorthAmericaCountry[count];

        for (int i = 0; i < this.length; i++) {
            if (countries[i] instanceof NorthAmericaCountry) {
                northAmericaCountries[i] = (NorthAmericaCountry) countries[i];
            }
        }

        return northAmericaCountries;
    }

    public SouthAmericaCountry[] filterSouthAmericaCountry() {
        int count = 0;
        for (Country country: countries) {
            if (country instanceof SouthAmericaCountry) {
                count++;
            }
        }

        SouthAmericaCountry[] southAmericaCountries = new SouthAmericaCountry[count];

        for (int i = 0; i < this.length; i++) {
            if (countries[i] instanceof SouthAmericaCountry) {
                southAmericaCountries[i] = (SouthAmericaCountry) countries[i];
            }
        }

        return southAmericaCountries;
    }

    public OceaniaCountry[] filterOceaniaCountry() {

        int count = 0;
        for (Country country: countries) {
            if (country instanceof OceaniaCountry) {
                count++;
            }
        }

        OceaniaCountry[] oceaniaCountries = new OceaniaCountry[count];

        for (int i = 0; i < this.length; i++) {
            if (countries[i] instanceof OceaniaCountry) {
                oceaniaCountries[i] = (OceaniaCountry) countries[i];
            }
        }

        return oceaniaCountries;
    }

    public Country[] filterMostPopulousCountries(int howMany) {
        /* TODO */
        Country[] arrayMostPopulousCountries = new Country[howMany];
        for (int i = 0; i < countries.length - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < countries.length; j++) {
                if (countries[j].getPopulation() < countries[j + 1].getPopulation()) {
                    Country temp = countries[j];
                    countries[j] = countries[j + 1];
                    countries[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break;
            }
        }

        System.arraycopy(countries, 0, arrayMostPopulousCountries, 0, howMany);

        return arrayMostPopulousCountries;
    }

    public Country[] filterLeastPopulousCountries(int howMany) {
        /* TODO */
        Country[] arrayLeastPopulousCountries = new Country[howMany];
        for (int i = 0; i < countries.length - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < countries.length; j++) {
                if (countries[j].getPopulation() > countries[j + 1].getPopulation()) {
                    Country temp = countries[j];
                    countries[j] = countries[j + 1];
                    countries[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break;
            }
        }

        System.arraycopy(countries, 0, arrayLeastPopulousCountries, 0, howMany);

        return arrayLeastPopulousCountries;
    }

    public Country[] filterLargestAreaCountries(int howMany) {
        /* TODO */
        Country[] arrayLargestAreaCountries = new Country[howMany];
        for (int i = 0; i < countries.length - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < countries.length; j++) {
                if (countries[j].getArea() < countries[j + 1].getArea()) {
                    Country temp = countries[j];
                    countries[j] = countries[j + 1];
                    countries[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break;
            }
        }

        System.arraycopy(countries, 0, arrayLargestAreaCountries, 0, howMany);

        return arrayLargestAreaCountries;
    }

    public Country[] filterSmallestAreaCountries(int howMany) {
        /* TODO */
        Country[] arraySmallestAreaCountries = new Country[howMany];
        for (int i = 0; i < countries.length - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < countries.length; j++) {
                if (countries[j].getArea() > countries[j + 1].getArea()) {
                    Country temp = countries[j];
                    countries[j] = countries[j + 1];
                    countries[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break;
            }
        }

        System.arraycopy(countries, 0, arraySmallestAreaCountries, 0, howMany);

        return arraySmallestAreaCountries;
    }

    public Country[] filterHighestGdpCountries(int howMany) {
        /* TODO */
        Country[] arrayHighestGdpCountries = new Country[howMany];
        for (int i = 0; i < countries.length - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < countries.length; j++) {
                if (countries[j].getArea() < countries[j + 1].getArea()) {
                    Country temp = countries[j];
                    countries[j] = countries[j + 1];
                    countries[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break;
            }
        }

        System.arraycopy(countries, 0, arrayHighestGdpCountries, 0, howMany);

        return arrayHighestGdpCountries;
    }

    public Country[] filterLowestGdpCountries(int howMany) {
        /* TODO */
        Country[] arrayLowestAreaCountries = new Country[howMany];
        for (int i = 0; i < countries.length - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < countries.length; j++) {
                if (countries[j].getArea() > countries[j + 1].getArea()) {
                    Country temp = countries[j];
                    countries[j] = countries[j + 1];
                    countries[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break;
            }
        }

        System.arraycopy(countries, 0, arrayLowestAreaCountries, 0, howMany);

        return arrayLowestAreaCountries;
    }

    public static String codeOfCountriesToString(Country[] countries) {
        StringBuilder codeOfCountries = new StringBuilder();
        codeOfCountries.append("[");
        for (int i = 0; i < countries.length; i++) {
            Country country = countries[i];
            if (country != null) {
                codeOfCountries.append(country.getCode())
                        .append(" ");
            }
        }

        return codeOfCountries.toString().trim() + "]";
    }

    public static void print(Country[] countries) {
        StringBuilder countriesString = new StringBuilder();
        countriesString.append("[");
        for (int i = 0; i < countries.length; i++) {
            Country country = countries[i];
            if (country != null) {
                countriesString.append(country.toString()).append("\n");
            }
        }
        System.out.print(countriesString.toString().trim() + "]");
    }

}

