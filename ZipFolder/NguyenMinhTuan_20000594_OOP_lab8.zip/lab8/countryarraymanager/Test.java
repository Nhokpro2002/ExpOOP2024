package hus.oop.lab8.countryarraymanager;

import java.lang.System;
import java.util.ArrayList;
import java.util.Arrays;

import java.util.List;

public class Test {
    public static void main(String[] args) {
        int[] intArray1 = {1, 2, 3, 4};
        int[] intArray2 = {4, 5, 6 ,7};
        System.arraycopy(intArray1, 2, intArray2, 2, 2);
        System.out.println(Arrays.toString(intArray2));

    }


}
